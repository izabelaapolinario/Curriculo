function leDados () {
    let strDados = localStorage.getItem('db');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse (strDados);
    }
    else {
        objDados = {
            "cadastro_empresa" :  [
         
         
            {
           
             
            "nome": "Francisco Moreira Lopes ",
            "datanascimento": "24/09/2001",
            "cnpj" : 3004004000101 ,
            "email":  "moreira@gmail.com",
            "senha":  "842561*",
            "celular": 9875329,
            "estado": "Itaobim",
            "cidade": "Minas Gerais"
           
            },
           
            {
            "nome": "Vinicius Mendes Costa",
            "datanascimento": "19/03/1997",
            "cnpj" : 3324004000110 ,
            "email":  "vimendes@gmail.com",
            "senha":  "9792798+",
            "celular": "9876205",
            "estado":  "Belo Horizonte",
            "cidade": "Minas Gerais"
           
            },
           
            {
            "nome": "Alex da Silva",
            "datanascimento": "30/01/2003",
            "cnpj" : 23004321000102 ,
            "email":  "silvalex@gmail.com",
            "senha":  "25098<",
            "celular":  "97827141",
            "estado":   "Minas Gerais",
            "cidade": "Belo Horizonte"
           
             }
            ] }}
           
         

    return objDados;
}

function salvaDados (dados) {
    localStorage.setItem ('db', JSON.stringify (dados));
}

function incluirContato (){
    // Ler os dados do localStorage
    let objDados = leDados();

    // Incluir um novo contato
    let strnome = document.getElementById ('nome').value;
    let strdatanascimento = document.getElementById ('datanascimento').value;
    let strcnpj = document.getElementById ('cnpj').value;
    let stremail = document.getElementById ('email').value;
    let strsenha = document.getElementById ('senha').value;
    let strcelular = document.getElementById ('celular').value;
    let strestado = document.getElementById ('estado').value;
    let strcidade = document.getElementById ('cidade').value;


    let novoContato = {
        nome: strnome,
        datanascimento: strdatanascimento,
        cpf: strcnpj,
        email: stremail,
        senha: strsenha,
        celular: strcelular,
        estado: strestado,
        cidade: strcidade,
    };
    objDados.cadastro_empresa.push(novoContato);
    alert("Cadastro criado com Sucesso");
    // Salvar os dados no localStorage novamente
    salvaDados (objDados);

    // Atualiza os dados da tela
    imprimeDados ();
    
}

function imprimeDados () {
    let tela = document.getElementById('tela');
    let strHtml = '';
    let objDados = leDados ();

    for (i=0; i< objDados.cadastro_empresa.length; i++) {
        strHtml += `<p>${objDados.cadastro_empresa[i].nome} - ${objDados.cadastro_empresa[i].datanascimento} - ${objDados.cadastro_empresa[i].cnpj}  - ${objDados.cadastro_empresa[i].email}  - ${objDados.cadastro_empresa[i].senha}  - ${objDados.cadastro_empresa[i].celular}  - ${objDados.cadastro_empresa[i].estado}  - ${objDados.cadastro_empresa[i].cidade}</p>`
    }

    tela.innerHTML = strHtml;
}

// Configura os botões

document.getElementById ('btnCadastrar').addEventListener ('click', incluirContato);


