function leDados () {
    let strDados = localStorage.getItem('db');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse (strDados);
    }
    else {
        objDados = {
            "cadastro_tutor" :  [
         
         
            {
           
             
            "nome": "Bernando Silva Lopes ",
            "datanascimento": "24/09/2001",
            "cpf" : 124578212,
            "email":  "bernandes@gmail.com",
            "senha":  "74363*",
            "celular": 9875329,
            "estado": "São Paulo",
            "cidade": "Joinville"
           
            },
           
            {
            "nome": "Lucas Bernardes Oliveira",
            "datanascimento": "19/03/1997",
            "cpf" : 51548152,
            "email":  "lucassouza@gmail.com",
            "senha":  "97927+",
            "celular": "9876205",
            "estado":  "Espirito Santo",
            "cidade": "Fortaleza"
           
            },
           
            {
            "nome": "Izabela Alves da Silva",
            "datanascimento": "30/01/2003",
            "cpf" : 215484204,
            "email":  "izabela786@gmail.com",
            "senha":  "96863<",
            "celular":  "97827141",
            "estado":   "Minas Gerais",
            "cidade": "Belo Horizonte"
           
             }
            ] }}
           
         

    return objDados;
}

function salvaDados (dados) {
    localStorage.setItem ('db', JSON.stringify (dados));
}

function incluirContato (){
    // Ler os dados do localStorage
    let objDados = leDados();

    // Incluir um novo contato
    let strnome = document.getElementById ('nome').value;
    let strdatanascimento = document.getElementById ('datanascimento').value;
    let strcpf = document.getElementById ('cpf').value;
    let stremail = document.getElementById ('email').value;
    let strsenha = document.getElementById ('senha').value;
    let strcelular = document.getElementById ('celular').value;
    let strestado = document.getElementById ('estado').value;
    let strcidade = document.getElementById ('cidade').value;


    let novoContato = {
        nome: strnome,
        datanascimento: strdatanascimento,
        cpf: strcpf,
        email: stremail,
        senha: strsenha,
        celular: strcelular,
        estado: strestado,
        cidade: strcidade,
    };
    objDados.cadastro_tutor.push(novoContato);
    alert("Cadastro criado com Sucesso");
    // Salvar os dados no localStorage novamente
    salvaDados (objDados);

    // Atualiza os dados da tela
    imprimeDados ();
    
}

function imprimeDados () {
    let tela = document.getElementById('tela');
    let strHtml = '';
    let objDados = leDados ();

    for (i=0; i< objDados.cadastro_tutor.length; i++) {
        strHtml += `<p>${objDados.cadastro_tutor[i].nome} - ${objDados.cadastro_tutor[i].datanascimento} - ${objDados.cadastro_tutor[i].cpf}  - ${objDados.cadastro_tutor[i].email}  - ${objDados.cadastro_tutor[i].senha}  - ${objDados.cadastro_tutor[i].celular}  - ${objDados.cadastro_tutor[i].estado}  - ${objDados.cadastro_tutor[i].cidade}</p>`
    }

    tela.innerHTML = strHtml;
}

// Configura os botões

document.getElementById ('btnCadastrar').addEventListener ('click', incluirContato);